

// import { NextRequest, NextResponse } from "next/server";
// import ExcelJS from "exceljs";
// import { writeFile, unlink } from "fs/promises";
// import { tmpdir } from "os";
// import path from "path";

// export const runtime = "nodejs";
// export const maxDuration = 300;

// function normalize(v: unknown): string {
//   if (v === null || v === undefined) return "";
//   return String(v).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
// }
// function normVal(v: unknown): string {
//   return String(v ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim().toUpperCase();
// }

// export async function POST(req: NextRequest) {
//   let tmpPath: string | null = null;
//   try {
//     const form = await req.formData();
//     const file = form.get("file") as File | null;
//     if (!file) return NextResponse.json({ error: "Ficheiro em falta." }, { status: 400 });

//     tmpPath = path.join(tmpdir(), `eact-${Date.now()}.xlsx`);
//     const bytes = new Uint8Array(await file.arrayBuffer());
//     await writeFile(tmpPath, bytes);

//     const wb = new ExcelJS.stream.xlsx.WorkbookReader(tmpPath, {
//       entries: "emit",
//       worksheets: "emit",
//       sharedStrings: "cache",
//     });

//     let cSit = -1, cContrato = -1, cEntSolta = -1, cEntAssoc = -1;
//     let totalBruto = 0;
//     const vistosEnc = new Set<unknown>();
//     let encerradas = 0;
//     const vistosSolta = new Set<unknown>();
//     let entidadesSoltas = 0;
//     let consecutiveEmpty = 0;

//     for await (const worksheetReader of wb) {
//       const sheetName = (worksheetReader as unknown as { name?: string }).name ?? "";
//       if (!normalize(sheetName).includes("export")) continue;

//       for await (const row of worksheetReader) {
//         const vals = row.values as unknown[];
//         if (row.number === 1) {
//           const header = vals.map(normalize);
//           cSit = header.indexOf(normalize("DSC_SIT"));
//           cContrato = header.indexOf(normalize("COD_CONTRATO"));
//           cEntSolta = header.indexOf(normalize("ENTIDADE_SOLTA"));
//           cEntAssoc = header.indexOf(normalize("ENTIDADE_ASSOCIADA"));
//           continue;
//         }
//         if (vals.every((v) => v === undefined || v === null)) {
//           consecutiveEmpty++;
//           // O ficheiro declara 1.048.576 linhas mas só tem dados reais nas
//           // primeiras centenas de milhares — corta ao fim de 2000 linhas
//           // vazias seguidas em vez de percorrer o resto à toa.
//           if (consecutiveEmpty > 2000) break;
//           continue;
//         }
//         consecutiveEmpty = 0;
//         totalBruto++;
//         if (normVal(vals[cSit]) === "ENCERRADA") {
//           const k = vals[cContrato];
//           if (!vistosEnc.has(k)) { vistosEnc.add(k); encerradas++; }
//         }
//         if (normVal(vals[cEntSolta]) === "SIM") {
//           const k = vals[cEntAssoc];
//           if (!vistosSolta.has(k)) { vistosSolta.add(k); entidadesSoltas++; }
//         }
//       }
//     }

//     return NextResponse.json({ totalBruto, encerradas, entidadesSoltas });
//   } catch (e) {
//     console.error("Erro /api/eact:", e);
//     return NextResponse.json(
//       { error: e instanceof Error ? `${e.name}: ${e.message}` : String(e) },
//       { status: 500 }
//     );
//   } finally {
//     if (tmpPath) await unlink(tmpPath).catch(() => {});
//   }
// }





// import { NextRequest, NextResponse } from "next/server";
// import ExcelJS from "exceljs";
// import { writeFile, unlink } from "fs/promises";
// import { tmpdir } from "os";
// import path from "path";

// export const runtime = "nodejs";
// export const maxDuration = 300;

// function normalize(v: unknown): string {
//   if (v === null || v === undefined) return "";

//   return String(v)
//     .normalize("NFD")
//     .replace(/[\u0300-\u036f]/g, "")
//     .toLowerCase()
//     .trim();
// }

// function normVal(v: unknown): string {
//   return String(v ?? "")
//     .replace(/\u00a0/g, " ")
//     .replace(/\s+/g, " ")
//     .trim()
//     .toUpperCase();
// }

// export async function POST(req: NextRequest) {
//   let tmpPath: string | null = null;

//   try {
//     console.log("=== /api/eact INICIO ===");

//     // 1. Receber o ficheiro diretamente
//     const formData = await req.formData();

//     const file = formData.get("file");

//     if (!(file instanceof File)) {
//       return NextResponse.json(
//         { error: "Ficheiro EACT em falta." },
//         { status: 400 }
//       );
//     }

//     console.log("EACT recebido:");
//     console.log("Nome:", file.name);
//     console.log("Tamanho:", file.size, "bytes");
//     console.log("Tipo:", file.type);

//     // 2. Guardar temporariamente no servidor
//     tmpPath = path.join(
//       tmpdir(),
//       `eact-${Date.now()}.xlsx`
//     );

//     const bytes = new Uint8Array(
//       await file.arrayBuffer()
//     );

//     await writeFile(tmpPath, bytes);

//     console.log("EACT gravado em:", tmpPath);

//     // 3. Abrir o Excel em streaming
//     const wb = new ExcelJS.stream.xlsx.WorkbookReader(
//       tmpPath,
//       {
//         entries: "emit",
//         worksheets: "emit",
//         sharedStrings: "cache",
//       }
//     );

//     let cSit = -1;
//     let cContrato = -1;
//     let cEntSolta = -1;
//     let cEntAssoc = -1;

//     let totalBruto = 0;

//     const vistosEnc = new Set<unknown>();
//     let encerradas = 0;

//     const vistosSolta = new Set<unknown>();
//     let entidadesSoltas = 0;

//     let consecutiveEmpty = 0;

//     // 4. Percorrer as worksheets
//     for await (const worksheetReader of wb) {
//       const sheetName =
//         (worksheetReader as unknown as { name?: string }).name ?? "";

//       console.log("Sheet encontrada:", sheetName);

//       // Só processar sheets cujo nome contém "export"
//       if (!normalize(sheetName).includes("export")) {
//         console.log("Sheet ignorada:", sheetName);
//         continue;
//       }

//       console.log("Processando sheet:", sheetName);

//       // 5. Percorrer as linhas
//       for await (const row of worksheetReader) {
//         const vals = row.values as unknown[];

//         // 6. Primeira linha = cabeçalho
//         if (row.number === 1) {
//           const header = vals.map(normalize);

//           console.log("Cabeçalho encontrado:", header);

//           cSit = header.indexOf(
//             normalize("DSC_SIT")
//           );

//           cContrato = header.indexOf(
//             normalize("COD_CONTRATO")
//           );

//           cEntSolta = header.indexOf(
//             normalize("ENTIDADE_SOLTA")
//           );

//           cEntAssoc = header.indexOf(
//             normalize("ENTIDADE_ASSOCIADA")
//           );

//           console.log("Índices encontrados:", {
//             cSit,
//             cContrato,
//             cEntSolta,
//             cEntAssoc,
//           });

//           if (
//             cSit === -1 ||
//             cContrato === -1 ||
//             cEntSolta === -1 ||
//             cEntAssoc === -1
//           ) {
//             throw new Error(
//               "Não foram encontradas todas as colunas necessárias no EACT."
//             );
//           }

//           continue;
//         }

//         // 7. Ignorar linhas vazias
//         if (
//           vals.every(
//             (v) => v === undefined || v === null
//           )
//         ) {
//           consecutiveEmpty++;

//           if (consecutiveEmpty > 2000) {
//             break;
//           }

//           continue;
//         }

//         consecutiveEmpty = 0;

//         totalBruto++;

//         // 8. ENCERRADAS
//         if (
//           normVal(vals[cSit]) === "ENCERRADA"
//         ) {
//           const k = vals[cContrato];

//           if (!vistosEnc.has(k)) {
//             vistosEnc.add(k);
//             encerradas++;
//           }
//         }

//         // 9. ENTIDADES SOLTAS
//         if (
//           normVal(vals[cEntSolta]) === "SIM"
//         ) {
//           const k = vals[cEntAssoc];

//           if (!vistosSolta.has(k)) {
//             vistosSolta.add(k);
//             entidadesSoltas++;
//           }
//         }
//       }
//     }

//     // 10. Resultado
//     console.log("=== EACT PROCESSADO ===");

//     console.log({
//       totalBruto,
//       encerradas,
//       entidadesSoltas,
//     });

//     return NextResponse.json({
//       totalBruto,
//       encerradas,
//       entidadesSoltas,
//     });

//   } catch (e) {
//     console.error("=== ERRO /api/eact ===");
//     console.error(e);

//     return NextResponse.json(
//       {
//         error:
//           e instanceof Error
//             ? `${e.name}: ${e.message}`
//             : String(e),
//       },
//       { status: 500 }
//     );

//   } finally {
//     // 11. Apagar ficheiro temporário
//     if (tmpPath) {
//       await unlink(tmpPath).catch(() => {});
//     }
//   }
// }

import { NextRequest, NextResponse } from "next/server";
import ExcelJS from "exceljs";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import path from "path";

export const runtime = "nodejs";
export const maxDuration = 300;

function normalize(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
function normVal(v: unknown): string {
  return String(v ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim().toUpperCase();
}

export async function POST(req: NextRequest) {
  let tmpPath: string | null = null;
  try {
    const { url } = await req.json();
    if (!url) return NextResponse.json({ error: "URL do ficheiro em falta." }, { status: 400 });

    const blobRes = await fetch(url);
    if (!blobRes.ok) {
      throw new Error(`Não consegui obter o ficheiro EACT do Blob. HTTP ${blobRes.status}`);
    }

    tmpPath = path.join(tmpdir(), `eact-${Date.now()}.xlsx`);
    const bytes = new Uint8Array(await blobRes.arrayBuffer());
    await writeFile(tmpPath, bytes);

    const wb = new ExcelJS.stream.xlsx.WorkbookReader(tmpPath, {
      entries: "emit",
      worksheets: "emit",
      sharedStrings: "cache",
    });

    let cSit = -1, cContrato = -1, cEntSolta = -1, cEntAssoc = -1;
    let totalBruto = 0;
    const vistosEnc = new Set<unknown>();
    let encerradas = 0;
    const vistosSolta = new Set<unknown>();
    let entidadesSoltas = 0;
    let consecutiveEmpty = 0;

    for await (const worksheetReader of wb) {
      const sheetName = (worksheetReader as unknown as { name?: string }).name ?? "";
      if (!normalize(sheetName).includes("export")) continue;

      for await (const row of worksheetReader) {
        const vals = row.values as unknown[];
        if (row.number === 1) {
          const header = vals.map(normalize);
          cSit = header.indexOf(normalize("DSC_SIT"));
          cContrato = header.indexOf(normalize("COD_CONTRATO"));
          cEntSolta = header.indexOf(normalize("ENTIDADE_SOLTA"));
          cEntAssoc = header.indexOf(normalize("ENTIDADE_ASSOCIADA"));
          continue;
        }
        if (vals.every((v) => v === undefined || v === null)) {
          consecutiveEmpty++;
          // O ficheiro declara 1.048.576 linhas mas só tem dados reais nas
          // primeiras centenas de milhares — corta ao fim de 2000 linhas
          // vazias seguidas em vez de percorrer o resto à toa.
          if (consecutiveEmpty > 2000) break;
          continue;
        }
        consecutiveEmpty = 0;
        totalBruto++;
        if (normVal(vals[cSit]) === "ENCERRADA") {
          const k = vals[cContrato];
          if (!vistosEnc.has(k)) { vistosEnc.add(k); encerradas++; }
        }
        if (normVal(vals[cEntSolta]) === "SIM") {
          const k = vals[cEntAssoc];
          if (!vistosSolta.has(k)) { vistosSolta.add(k); entidadesSoltas++; }
        }
      }
    }

    return NextResponse.json({ totalBruto, encerradas, entidadesSoltas });
  } catch (e) {
    console.error("Erro /api/eact:", e);
    return NextResponse.json(
      { error: e instanceof Error ? `${e.name}: ${e.message}` : String(e) },
      { status: 500 }
    );
  } finally {
    if (tmpPath) await unlink(tmpPath).catch(() => {});
  }
}